﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Slikar
{
    public partial class Form1 : Form
    {
        bool risi = false;

        int pX = -1;
        int pY = -1;

        Bitmap narisi;
        public Form1()
        {
            InitializeComponent();
            narisi = new Bitmap(ClientSize.Width, ClientSize.Height, CreateGraphics());
            pictureBox1.BackgroundImage = narisi;
            Graphics.FromImage(narisi).Clear(Color.White);
        }

        private void Narisi(object sender, EventArgs e)
        {
            
        }

        private void Narisi(object sender, MouseEventArgs e)
        {
  
            if (risi)
                {
                    Graphics panel = Graphics.FromImage(pictureBox1.BackgroundImage);
                    Pen pen = new Pen(Color.Black, 2);
                    panel.DrawLine(pen, pX, pY, e.X, e.Y);
                    CreateGraphics().DrawImageUnscaled(narisi, new Point(0, 0));
            }

                pX = e.X;
                pY = e.Y;

        }

        private void Pritisni_misko(object sender, MouseEventArgs e)
        {
            risi = true;

            pX = e.X;
            pY = e.Y;
        }

        private void Spusti_misko(object sender, MouseEventArgs e)
        {
            risi = false;
        }

        private void Narisi(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(narisi, new Point(0, 0));
        }

        private void Zbrisi(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Zbrisi(object sender, MouseEventArgs e)
        {
            pictureBox1.BackgroundImage = narisi;
        }
        private void Zbrisi1(object sender, PaintEventArgs e)
        {
            e.Graphics.Clear(new Color());
        }
    }
}
