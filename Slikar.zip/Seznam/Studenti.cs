﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seznam
{
    class Studenti
    {
        private string ime;
        private string priimek;
        private string spol;
        private string datum;
     public Studenti(string ime, string priimek, string spol, string datum)
        {

        }
        public string Ime
        {
            get { return ime; }
            set { string vr = value;
                ime = vr;
            }
        }
        public string Priimek
        {
            get { return priimek; }
            set
            {
                string vr = value;
                priimek = vr;
            }
        }
        public string Spol
        {
            get { return spol; }
            set
            {
                string vr = value;
                spol = vr;
            }
        }
        public string Datum
        {
            get { return datum; }
            set
            {
                string vr = value;
                ime = vr;
            }
        }
    }
}
