﻿namespace Seznam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.zavihki = new System.Windows.Forms.TabControl();
            this.button1 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.ime = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ime_studenta = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.priimek = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.spol = new System.Windows.Forms.Label();
            this.dodaj = new System.Windows.Forms.Button();
            this.tabPage2.SuspendLayout();
            this.zavihki.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(617, 524);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Dodaj študenta";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(617, 524);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Študent";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // zavihki
            // 
            this.zavihki.Controls.Add(this.tabPage1);
            this.zavihki.Controls.Add(this.tabPage2);
            this.zavihki.Location = new System.Drawing.Point(13, 13);
            this.zavihki.Name = "zavihki";
            this.zavihki.SelectedIndex = 0;
            this.zavihki.Size = new System.Drawing.Size(625, 550);
            this.zavihki.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(279, 474);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "gumb";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(213, 177);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(194, 20);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // ime
            // 
            this.ime.Location = new System.Drawing.Point(213, 30);
            this.ime.Name = "ime";
            this.ime.Size = new System.Drawing.Size(194, 20);
            this.ime.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dodaj);
            this.groupBox1.Controls.Add(this.spol);
            this.groupBox1.Controls.Add(this.priimek);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.ime_studenta);
            this.groupBox1.Controls.Add(this.ime);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Location = new System.Drawing.Point(109, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(453, 361);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dodaj";
            // 
            // ime_studenta
            // 
            this.ime_studenta.AutoSize = true;
            this.ime_studenta.Location = new System.Drawing.Point(152, 33);
            this.ime_studenta.Name = "ime_studenta";
            this.ime_studenta.Size = new System.Drawing.Size(23, 13);
            this.ime_studenta.TabIndex = 4;
            this.ime_studenta.Text = "ime";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(213, 77);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(194, 20);
            this.textBox1.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(213, 127);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(194, 21);
            this.comboBox1.TabIndex = 6;
            // 
            // priimek
            // 
            this.priimek.AutoSize = true;
            this.priimek.Location = new System.Drawing.Point(152, 84);
            this.priimek.Name = "priimek";
            this.priimek.Size = new System.Drawing.Size(40, 13);
            this.priimek.TabIndex = 7;
            this.priimek.Text = "priimek";
            // 
            // spol
            // 
            this.spol.AutoSize = true;
            this.spol.Location = new System.Drawing.Point(155, 134);
            this.spol.Name = "spol";
            this.spol.Size = new System.Drawing.Size(26, 13);
            this.spol.TabIndex = 8;
            this.spol.Text = "spol";
            // 
            // dodaj
            // 
            this.dodaj.Location = new System.Drawing.Point(190, 332);
            this.dodaj.Name = "dodaj";
            this.dodaj.Size = new System.Drawing.Size(75, 23);
            this.dodaj.TabIndex = 9;
            this.dodaj.Text = "dodaj";
            this.dodaj.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 610);
            this.Controls.Add(this.zavihki);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabPage2.ResumeLayout(false);
            this.zavihki.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl zavihki;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox ime;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button dodaj;
        private System.Windows.Forms.Label spol;
        private System.Windows.Forms.Label priimek;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label ime_studenta;
        private System.Windows.Forms.BindingSource bindingSource1;
    }
}

