﻿/*
 *  vir
 * https://www.codeproject.com/Articles/334773/Graphical-BinaryTrees
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;

namespace Vizualizacija_Dreves
{
    class Vozel
    {
        private bool isk; //označi le tisti vozel, ki ga iščemo
        private bool iskanje; //označi pot
        private bool risanje_iskanje_levo { get; set; } //risanje iskanje
        private bool risanje_iskanje_desno { get; set; }
        public int St_el { get; set; } //steje število elementov
        public int Vrednost { get; set; }
        public Vozel Levo { get; set; }
        public Vozel Desno { get; set; }
        public bool JeList { get { return Desno == null && Levo == null; } }
        public Vozel(int vrednost, Vozel levo, Vozel desno)
        {
            St_el = 0;
            Desno = levo;
            Levo = desno;
            Vrednost = vrednost;
        }
        public Vozel(int vrednost) : this(vrednost, null, null) { }
        public Vozel() : this(int.MinValue, null, null)
        {
            Vozel drevo = new Vozel(int.MinValue);
        }
        private bool _je_Spremenjen = true;
        /// <summary>
        /// ali je spremenjen - uporabljeno za risanje
        /// če je spremenjen, nariši sliko
        /// </summary>
        public bool JeSpremenjen
        {
            get
            {
                if (_je_Spremenjen)
                    return true;
                bool spremenjeniNalsedniki = false;
                if (Levo != null)
                    spremenjeniNalsedniki |= Levo.JeSpremenjen;
                if (Desno != null)
                    spremenjeniNalsedniki |= Desno.JeSpremenjen;
                return spremenjeniNalsedniki;
            }
            private set { _je_Spremenjen = value; }
        }


        /// <summary>
        /// Najde vrednost
        /// </summary>
        /// <param name="vrednost">Vrednost, ki jo iščemo</param>
        /// <param name="isci">Ali mora prebarvati staro vrednost?</param>
        /// <returns></returns>
        public bool Najdi(int s, bool isci)
        {
            isk = false;
            iskanje = isci;
            Vozel vozel = this;
            if (vozel == null)
            {
                risanje_iskanje_desno = false;
                risanje_iskanje_levo = false;
                isk = false;
                return false;
            }
            if (vozel.Vrednost == s)
            {   //izklopi risanje in vrne true
                risanje_iskanje_desno = false;
                risanje_iskanje_levo = false;
                isk = true;
                return true;
            }
            else if (vozel.Vrednost < s)
            {
                risanje_iskanje_desno = true;
                risanje_iskanje_levo = false;
                if (vozel.Desno != null && vozel.Levo != null)
                {
                    vozel.Levo.JeSpremenjen = false; // izklopi risanje
                    vozel.Desno.JeSpremenjen = false;
                }
                if (vozel.Desno != null)
                {
                    vozel.Desno.JeSpremenjen = true;
                    return vozel.Desno.Najdi(s, iskanje);
                } 
                else return false; //elementa ni
            }
            else if (vozel.Vrednost > s)
            {
                risanje_iskanje_levo = true;
                risanje_iskanje_desno = false;
                if (vozel.Desno != null && vozel.Levo != null)
                {
                    //vozel.JeSpremenjen = true;
                    vozel.Levo.JeSpremenjen = false;
                    vozel.Desno.JeSpremenjen = false;
                }
                if (vozel.Levo!=null)
                {
                    vozel.Levo.JeSpremenjen = true;
                    return vozel.Levo.Najdi(s, iskanje);
                }   
                return false; //elementa ni
            }
            return false;
        }
        /// <summary>
        /// Sprehod po drevesu najdi vrednost, preveri ali je v dvojiškem drevesu, za funkcijo random
        /// https://codereview.stackexchange.com/questions/92618/simple-binary-search-tree
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public bool Sprehod(int s)
        {
            isk = false;
            iskanje = false;
            Vozel vozel = this;
            if (vozel == null)
                return false;
            if (vozel.Vrednost == s)
                return true;
            else if (vozel.Vrednost < s)
            {
                if (vozel.Desno != null) return vozel.Desno.Sprehod(s);
                else return false; //elementa ni
            }
            else if (vozel.Vrednost > s)
            {
                if (vozel.Levo != null) return vozel.Levo.Sprehod(s);
                else return false; //elementa ni
            }
            return false;
        }
        /// <summary>
        /// Vmesni pregled iterator
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Vozel> VmesniPregled()
        {
            if (this != null)
            {
                if (Levo != null)
                {
                    foreach (Vozel levi in Levo.VmesniPregled())
                    {
                        yield return levi;
                    }
                }
                yield return this;
                if (Desno != null)
                {
                    foreach (Vozel desni in Desno.VmesniPregled())
                    {
                        yield return desni;
                    }
                }
            }
        }
        public bool Vstavi(Vozel drevo)
        {
            isk = false;
            iskanje = false;
            var res = false;
            if (drevo.Vrednost < Vrednost) // dodaj na levo
            {
                res = true;
                if (Levo == null)
                    Levo = drevo;
                else
                    res = Levo.Vstavi(drevo);
                JeSpremenjen = true;
                St_el++;
            }
            else if (drevo.Vrednost > Vrednost) // dodaj na desno.
            {
                res = true;
                JeSpremenjen = true;
                if (Desno == null)
                    Desno = drevo;
                else
                    res = Desno.Vstavi(drevo);
                St_el++;
            }
            else
            {
                throw new Exception("Vrednost je že v drevesu."); // dovoljena le 1 pojavitev v drevesu
            }
            return res;
        }
        public bool Odstrani(int vrednost, out bool vsebuje)
        {
            isk = false;
            iskanje = false;
            Vozel Vozel_odstrani;
            vsebuje = false;
            // iskanje
            var levi = vrednost<Vrednost;
            if (levi)
                Vozel_odstrani = Levo;
            else if (vrednost>Vrednost)
                Vozel_odstrani = Desno;
            else
            {
                if (Levo != null)
                    Levo.JeSpremenjen = true;
                if (Desno != null)
                    Desno.JeSpremenjen = true;
                vsebuje = true;
                return false; // ni še odstranjen
            }
            if (Vozel_odstrani == null)
                return false;
            var result = Vozel_odstrani.Odstrani(vrednost, out bool vsebovan_na_sinu);
            if (vsebovan_na_sinu) //
            {
                JeSpremenjen = true;
                if (Vozel_odstrani.Levo == null && Vozel_odstrani.Desno == null)// 1. odstranjevanje, če ni sinov
                {
                    if (levi) Levo = null; else Desno = null;
                    St_el--;
                }
                else if (Vozel_odstrani.Desno == null)                        // 2. odstranjevalni vozel ima levega sina
                {
                    if (levi) Levo = Vozel_odstrani.Levo; else Desno = Vozel_odstrani.Levo;
                    St_el--;
                }
                else                                                        // levi in desni nista prazna
                {
                    if (Vozel_odstrani.Desno.Levo == null)                    // 3. desni sin nima levega sina
                    {
                        Vozel_odstrani.Desno.Levo = Vozel_odstrani.Levo;
                        if (levi)
                            Levo = Vozel_odstrani.Desno;
                        else
                            Desno = Vozel_odstrani.Desno;
                        St_el--;
                    }
                    else                                                    // 4. desni sin ima levega sina
                    {
                        Vozel naj_levi = null;
                        for (var node = Vozel_odstrani.Desno; node != null; node = node.Levo) //sprehod do najbolj levega sina.
                            if (node.Levo == null)
                                naj_levi = node;
                        var v = naj_levi.Vrednost;

                        // rekruzivni klic odstrani najbolj levega sina v desnem poddrevesu
                        Odstrani(naj_levi.Vrednost, out bool temp);
                        Vozel_odstrani.Vrednost = v;
                    }
                }
                return true;
            }
            if (result == true)
                St_el--;
            return result;
        }
        public bool Obstaja(int vrednost)
        {
            var res = vrednost.Equals(Vrednost);
            if (!res && Levo != null)
                res = Levo.Obstaja(vrednost);
            if (!res && Desno != null)
                res = Desno.Obstaja(vrednost);
            return res;
        }
        /// <summary>
        /// prešteje vozlišča poddreves.
        /// </summary>
        public int Prestej
        {
            get
            {
                return 1 + (Levo != null ? Levo.Prestej : 0) + (Desno != null ? Desno.Prestej : 0);
            }
        }

        //metode za risanje
        //https://www.codeproject.com/Articles/334773/Graphical-BinaryTrees

        private static Bitmap _vozelBG = new Bitmap(30, 25);
        private static Size _prostiProstor = new Size(_vozelBG.Width / 8, (int)(_vozelBG.Height * 1.3f));
        private static readonly float Coef = _vozelBG.Width / 40f;

        /// <summary>
        /// Statični konstruktor
        /// </summary>
        static Vozel()
        {
            var g = Graphics.FromImage(_vozelBG);                                    // dobi grafiko iz slike 
            g.SmoothingMode = SmoothingMode.HighQuality;                            // nastavi smoothing način
            var rcl = new Rectangle(1, 1, _vozelBG.Width - 2, _vozelBG.Height - 2);   // dobi pravokotnik za risanje
            g.FillRectangle(Brushes.White, rcl);
            g.DrawEllipse(new Pen(Color.Green, 1.2f), rcl);                          // nariše elipso
        }
        Image _ZadnjaSlika;
        private int _zadnja_lokacija_slike;
        private static Font font = new Font("Tahoma", 10f * Coef);

        public Image Draw(out int center)
        {
            center = _zadnja_lokacija_slike;
            if (!JeSpremenjen) // če so trenutni vozel in njegovi naslednjiki nespremnjeni vrni zadnjo sliko
                return _ZadnjaSlika;

            var lCenter = 0;
            var rCenter = 0;

            Image lVozelSlika = null, dVozelSlika = null;
            if (Levo != null)       // nariši sliko levega vozla
                lVozelSlika = Levo.Draw(out lCenter);
            if (Desno != null)      // nariši sliko desnega vozla
                dVozelSlika = Desno.Draw(out rCenter);

            // nariši trenutni vozel in naslednjega (levi in desni)
            Size lVelikost = new Size();
            Size rVelikost = new Size();
            bool pod = (lVozelSlika != null) || (dVozelSlika != null);// če je true ima trenutni sina.
            if (lVozelSlika != null)
                lVelikost = lVozelSlika.Size;
            if (dVozelSlika != null)
                rVelikost = dVozelSlika.Size;

            var maxVišina = lVelikost.Height;
            if (maxVišina < rVelikost.Height)
                maxVišina = rVelikost.Height;

            if (lVelikost.Width <= 0)
                lVelikost.Width = (_vozelBG.Width - _prostiProstor.Width) / 2;
            if (rVelikost.Width <= 0)
                rVelikost.Width = (_vozelBG.Width - _prostiProstor.Width) / 2;

            var resSize = new Size
            {
                Width = lVelikost.Width + rVelikost.Width + _prostiProstor.Width,
                Height = _vozelBG.Size.Height + (pod ? maxVišina + _prostiProstor.Height : 0)
            };

            var result = new Bitmap(resSize.Width, resSize.Height);
            var g = Graphics.FromImage(result);
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.FillRectangle(Brushes.White, new Rectangle(new Point(0, 0), resSize));
            g.DrawImage(_vozelBG, lVelikost.Width - _vozelBG.Width / 2 + _prostiProstor.Width / 2, 0);
            var str = Vrednost.ToString();
            if(isk&&iskanje)
            g.DrawString(str, font, Brushes.Red, lVelikost.Width - _vozelBG.Width / 2 + _prostiProstor.Width / 2 + (2 + (str.Length == 1 ? 10 : str.Length == 2 ? 5 : 0)) * Coef, _vozelBG.Height / 2f - 12 * Coef);//številka
            else
            g.DrawString(str, font, Brushes.Black, lVelikost.Width - _vozelBG.Width / 2 + _prostiProstor.Width / 2 + (2 + (str.Length == 1 ? 10 : str.Length == 2 ? 5 : 0)) * Coef, _vozelBG.Height / 2f - 12 * Coef);//številka
            center = lVelikost.Width + _prostiProstor.Width / 2;
            Pen svinčnik;
            svinčnik = new Pen(Brushes.Green, 1.2f * Coef) // povezave
            {
                EndCap = LineCap.ArrowAnchor,
                StartCap = LineCap.Round
            };
            Pen svinčnik1;
            svinčnik1 = new Pen(Brushes.Red, 1.2f * Coef) // povezave pri iskanju
            {
                EndCap = LineCap.ArrowAnchor,
                StartCap = LineCap.Round
            };


            float x1 = center;
            float y1 = _vozelBG.Height;
            float y2 = _vozelBG.Height + _prostiProstor.Height;
            float x2 = lCenter;
            var h = Math.Abs(y2 - y1);
            var w = Math.Abs(x2 - x1);
            if (lVozelSlika != null)
            {
                g.DrawImage(lVozelSlika, 0, _vozelBG.Size.Height + _prostiProstor.Height);
                var points1 = new List<PointF>
                                  {
                                      new PointF(x1, y1),
                                      new PointF(x1 - w/6, y1 + h/3.5f),
                                      new PointF(x2 + w/6, y2 - h/3.5f),
                                      new PointF(x2, y2),
                                  };
                //risanje črt levo
                if (iskanje && risanje_iskanje_levo) // označi po katerih povezavah je šel.
                    g.DrawCurve(svinčnik1, points1.ToArray(), 0.5f);
                else
                    g.DrawCurve(svinčnik, points1.ToArray(), 0.5f);

            }
            if (dVozelSlika != null)
            {
                g.DrawImage(dVozelSlika, lVelikost.Width + _prostiProstor.Width, _vozelBG.Size.Height + _prostiProstor.Height);
                x2 = rCenter + lVelikost.Width + _prostiProstor.Width;
                w = Math.Abs(x2 - x1);
                var points = new List<PointF>
                                 {
                                     new PointF(x1, y1),
                                     new PointF(x1 + w/6, y1 + h/3.5f),
                                     new PointF(x2 - w/6, y2 - h/3.5f),
                                     new PointF(x2, y2)
                                 };
                g.DrawCurve(svinčnik, points.ToArray(), 0.5f); //risanje črt desno
                if (iskanje && risanje_iskanje_desno) // označi po katerih povezavah je šel.
                    g.DrawCurve(svinčnik1, points.ToArray(), 0.5f);
                else
                    g.DrawCurve(svinčnik, points.ToArray(), 0.5f);
            }
            JeSpremenjen = false;
            _ZadnjaSlika = result;
            _zadnja_lokacija_slike = center;
            return result;
        }
    }
}
