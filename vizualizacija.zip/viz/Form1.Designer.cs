﻿namespace Vizualizacija_Dreves
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GumbIsci = new System.Windows.Forms.Button();
            this.GumbOdstrani = new System.Windows.Forms.Button();
            this.iskalnik = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gumb_dodaj = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.prikaz = new System.Windows.Forms.CheckBox();
            this.igra = new System.Windows.Forms.Button();
            this.Random = new System.Windows.Forms.Button();
            this.prikazovalnik1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GumbIsci
            // 
            this.GumbIsci.Location = new System.Drawing.Point(165, 3);
            this.GumbIsci.Name = "GumbIsci";
            this.GumbIsci.Size = new System.Drawing.Size(75, 23);
            this.GumbIsci.TabIndex = 1;
            this.GumbIsci.Text = "Isci";
            this.GumbIsci.UseVisualStyleBackColor = true;
            this.GumbIsci.Click += new System.EventHandler(this.GumbIsci_Click);
            // 
            // GumbOdstrani
            // 
            this.GumbOdstrani.Location = new System.Drawing.Point(246, 3);
            this.GumbOdstrani.Name = "GumbOdstrani";
            this.GumbOdstrani.Size = new System.Drawing.Size(75, 23);
            this.GumbOdstrani.TabIndex = 2;
            this.GumbOdstrani.Text = "Odstrani";
            this.GumbOdstrani.UseVisualStyleBackColor = true;
            this.GumbOdstrani.Click += new System.EventHandler(this.GumbOdstrani_ClickAsync);
            // 
            // iskalnik
            // 
            this.iskalnik.Location = new System.Drawing.Point(408, 3);
            this.iskalnik.Name = "iskalnik";
            this.iskalnik.Size = new System.Drawing.Size(100, 20);
            this.iskalnik.TabIndex = 3;
            this.iskalnik.KeyDown += new System.Windows.Forms.KeyEventHandler(this.iskalnik_KeyDown);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(0, 50);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(818, 513);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // gumb_dodaj
            // 
            this.gumb_dodaj.Location = new System.Drawing.Point(3, 3);
            this.gumb_dodaj.Name = "gumb_dodaj";
            this.gumb_dodaj.Size = new System.Drawing.Size(75, 23);
            this.gumb_dodaj.TabIndex = 5;
            this.gumb_dodaj.Text = "Dodaj";
            this.gumb_dodaj.UseVisualStyleBackColor = true;
            this.gumb_dodaj.Click += new System.EventHandler(this.gumb_dodaj_Click);
            // 
            // panel1
            // 
            this.panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panel1.Controls.Add(this.prikaz);
            this.panel1.Controls.Add(this.igra);
            this.panel1.Controls.Add(this.Random);
            this.panel1.Controls.Add(this.prikazovalnik1);
            this.panel1.Controls.Add(this.gumb_dodaj);
            this.panel1.Controls.Add(this.GumbIsci);
            this.panel1.Controls.Add(this.iskalnik);
            this.panel1.Controls.Add(this.GumbOdstrani);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(795, 37);
            this.panel1.TabIndex = 6;
            // 
            // prikaz
            // 
            this.prikaz.AutoSize = true;
            this.prikaz.Location = new System.Drawing.Point(514, 7);
            this.prikaz.Name = "prikaz";
            this.prikaz.Size = new System.Drawing.Size(157, 17);
            this.prikaz.TabIndex = 9;
            this.prikaz.Text = "Prikaži pri brisanju animacijo";
            this.prikaz.UseVisualStyleBackColor = true;
            // 
            // igra
            // 
            this.igra.Location = new System.Drawing.Point(327, 3);
            this.igra.Name = "igra";
            this.igra.Size = new System.Drawing.Size(75, 23);
            this.igra.TabIndex = 8;
            this.igra.Text = "Igra";
            this.igra.UseVisualStyleBackColor = true;
            this.igra.Click += new System.EventHandler(this.igra_Click);
            // 
            // Random
            // 
            this.Random.Location = new System.Drawing.Point(84, 3);
            this.Random.Name = "Random";
            this.Random.Size = new System.Drawing.Size(75, 23);
            this.Random.TabIndex = 7;
            this.Random.Text = "RND";
            this.Random.UseVisualStyleBackColor = true;
            this.Random.Click += new System.EventHandler(this.Random_Click);
            // 
            // prikazovalnik1
            // 
            this.prikazovalnik1.AutoSize = true;
            this.prikazovalnik1.Location = new System.Drawing.Point(679, 8);
            this.prikazovalnik1.Name = "prikazovalnik1";
            this.prikazovalnik1.Size = new System.Drawing.Size(103, 13);
            this.prikazovalnik1.TabIndex = 6;
            this.prikazovalnik1.Text = "Število elementov: 0";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 562);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Iskalna drevesa";
            this.Resize += new System.EventHandler(this.Form1_ResizeEnd);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button GumbIsci;
        private System.Windows.Forms.Button GumbOdstrani;
        private System.Windows.Forms.TextBox iskalnik;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button gumb_dodaj;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label prikazovalnik1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button Random;
        private System.Windows.Forms.Button igra;
        private System.Windows.Forms.CheckBox prikaz;
    }
}

