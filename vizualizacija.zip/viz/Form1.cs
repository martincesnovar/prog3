﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vizualizacija_Dreves
{
    public partial class Form1 : Form
    {
        const int k = 100000;
        int stari = int.MinValue;
        public Form1()
        {
            InitializeComponent();
        }
        int i;
        Vozel drevo=new Vozel(int.MinValue); // ta vrednost ne bo prikazana na sliki #1
        /// <summary>
        /// risanje drevesa
        /// </summary>
        async void PaintTreeAsync()
        {
            if (drevo == null) return;
            else if (drevo.Desno == null) // #1
                pictureBox1.Image = null;
            else
            {
                await Task.Delay(250);
                try
                {
                    pictureBox1.Image = drevo.Desno.Draw(out i); // #1
                }
                catch { }
            }
        }

        private void gumb_dodaj_Click(object sender, EventArgs e)
        {
            drevo.Najdi(stari, false);
            try
            {
                if (int.TryParse(iskalnik.Text, out int st))
                {
                    int val = int.Parse(iskalnik.Text);
                    if (val < 100000 && val > -100000)
                    {
                        drevo.Vstavi(new Vozel(val));
                        PaintTreeAsync();
                        this.Update();
                        prikazovalnik1.Text = "Število elementov: " + drevo.St_el.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Dovoljena so le cela števila na intervalu [" + ((-1)*k+1) + ", " + (k-1) + "].", "Napaka v vnosu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
               
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void GumbOdstrani_ClickAsync(object sender, EventArgs e)
        {
            drevo.Najdi(stari, false);
            try
            {
                string niz = iskalnik.Text;
                if (int.TryParse(niz, out int st))
                {
                    int val = int.Parse(niz);
                    if (val == int.MinValue)
                        MessageBox.Show("Dovoljena so le cela števila na intervalu [" + ((-1)*k+1) + ", " + (k-1) + "].", "Napaka v vnosu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    if (prikaz.Checked)
                    {
                        drevo.Najdi(val, true); //najprej najde element
                        PaintTreeAsync();
                        Update();
                        await Task.Delay(1000);
                        drevo.Najdi(val, false); //pobriše oznako pred brisanjem - če elementa ni v drevesu
                    }
                    drevo.Odstrani(val,out bool vsebuje);
                    PaintTreeAsync();
                    Update();
                    prikazovalnik1.Text = "Število elementov: " + drevo.St_el.ToString();
                    if (drevo.Desno != null)
                        iskalnik.Text = drevo.Desno.Vrednost.ToString(); //#1 napiše trenutni koren v iskalnik
                }
                else
                {
                    MessageBox.Show("Dovoljena so le cela števila na intervalu [" + ((-1) * k + 1) + ", " + (k-1) + "].", "Napaka v vnosu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message, "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        /// <summary>
        /// bindanje bližnjic
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void iskalnik_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) gumb_dodaj_Click(gumb_dodaj, new EventArgs());
            else if (e.KeyCode == Keys.Delete) GumbOdstrani_ClickAsync(GumbOdstrani, new EventArgs());
            else if (e.KeyCode == Keys.Control) GumbIsci_Click(GumbIsci, new EventArgs());
            else if (e.KeyCode == Keys.Alt) Random_Click(Random, new EventArgs());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void GumbIsci_Click(object sender, EventArgs e)  
        {
            bool vsebuje;
            if (drevo != null)
            {
                if (int.TryParse(iskalnik.Text, out int k))
                {
                    vsebuje = drevo.Najdi(stari, false);//prebarva prejšne povezave
                    stari = int.Parse(iskalnik.Text);
                    vsebuje = drevo.Najdi(stari, true); //iskanje
                    PaintTreeAsync();
                    Update();
                    if (!vsebuje)
                        MessageBox.Show("Elementa ni v iskalnem drevesu", "Ni elementa", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                    MessageBox.Show("Ni celo število", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Ni drevesa", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            
        }
        /// <summary>
        /// Vstavi random število
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Random_Click(object sender, EventArgs e)
        {
            Tuple<int, bool> tup;
            drevo.Najdi(stari, false);
            int st=0;
            int t1=0;
            int t=0;
            string[] a;
            string niz = iskalnik.Text;
            if (niz.Contains(","))
            {
                a = niz.Split(',');
                if (int.TryParse(a[0], out int x) && (int.TryParse(a[1], out int y)))
                {
                    t = int.Parse(a[0]);
                    t1 = int.Parse(a[1]);
                }
                tup = generator(t, t1);
            }
            else if (int.TryParse(iskalnik.Text, out int k1))
            {
                t1 = int.Parse(iskalnik.Text);
                tup = generator(0, t1);
            }
            else
                tup = generator(0, 0);
            st = tup.Item1;

            try
            {
                while (drevo.Sprehod(st))
                {
                    bool nap = false;
                    if (t1 != 0 && t != 0)
                        tup = generator(t, t1);
                    else if (t == 0 && t1 > 0)
                        tup = generator(0, t1);
                    else if (t > 0 && t1 == 0)
                        tup = generator(0, t);
                    else if (int.TryParse(iskalnik.Text, out int k1))
                        tup = generator(0, int.Parse(iskalnik.Text));
                    else tup = generator(0, 0);
                    st = tup.Item1;
                    nap = tup.Item2;
                    if (nap) // prepreči neskončno zanko
                        break;
                }
                drevo.Vstavi(new Vozel(st));
                PaintTreeAsync();
                Update();
                prikazovalnik1.Text = "Število elementov: " + drevo.St_el.ToString();
                //iskalnik.Text = st.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// izbere naključno število na intervalu [a,b].
        /// </summary>
        /// <param name="a">začetek intervala</param>
        /// <param name="b">konec intervala</param>
        /// <returns>število</returns>
        private Tuple<int,bool> generator(int a, int b)
        {
            bool nap=false;
            Random gen = new Random();
            int stevec = 0; // prešteje elemente v vmesnem pregledu od a naprej
            int k=10000;
            int st;
            if (a != 0 || b != 0)
            {
                if (a > b)
                {
                    st = a;
                    a = b;
                    b = st;
                }
            st = gen.Next(a, b + 1);
            }
            else st = gen.Next(k); // random vrne do k-1, če ničesar ne podamo

            if (drevo.Desno != null)
            {//pregledamo vmesni pregled, če so na intervalu [a,b] vsa števila gremo iz zanke, ki vstavlja naključna števila
                foreach (Vozel x in drevo.Desno.VmesniPregled())
                {
                    if (x.Vrednost >= a && x.Vrednost <=b)
                    {
                        stevec++;
                    }
                    if (stevec > b - a)
                        nap = true;
                    if (x.Vrednost > b)
                        break;
                }
            }
            Tuple<int, bool> elementi = new Tuple<int, bool>(st,nap);
            return elementi;
        }

        private void igra_Click(object sender, EventArgs e)
        {
            igra_brisi_vstaviAsync(200);
        }
        /// <summary>
        /// Zbriše element in ga vstavi nazaj, animacija
        /// </summary>
        /// <param name="t">Čas v milisekundah</param>
        private async void igra_brisi_vstaviAsync(int t)
        {
            igra.Enabled = false; //onemogoči gumb
            int k = 1;
            if (int.TryParse(iskalnik.Text, out int k1))
                k = int.Parse(iskalnik.Text);
            for (int i = 0; i < k; i++)
            {
                if (drevo != null && drevo.Desno != null)
                {
                    int vrednost = drevo.Desno.Vrednost;
                    drevo.Odstrani(vrednost, out bool a);
                    drevo.Vstavi(new Vozel(vrednost));
                    await Task.Delay(t);
                    PaintTreeAsync();
                    Update();
                }
            }
            igra.Enabled = true;
        }
        /// <summary>
        /// S tem prilagodimo velikost risalnega polja
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_ResizeEnd(object sender, EventArgs e)
        {
            pictureBox1.Size = new System.Drawing.Size(ClientSize.Width, ClientSize.Height);
        }
    }
}
